// Main entry point for Hostinger hosting
require('dotenv').config();
require('./server/index.js');
